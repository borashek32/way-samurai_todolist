import React from "react";
import {TasksPropsType} from "./App";


export type TodoListPropsType = {
    title: string,
    tasks: Array<TasksPropsType>
}

export const TodoList = (props: TodoListPropsType) => {
    // let tasksMap = props.tasks.map(el => <li><input type="checkbox" checked={ el.isDone }/> <span>{ el.title }</span></li>);
    return (
        <div>
            <div>
                <h3>{props.title}</h3>
                <div>
                    <input/>
                    <button>+</button>
                </div>
                <ul>
                    {/* reduced form, not good */}
                    {/*{ tasksMap }*/}
                    {/*{props.tasks.map(el => <li><input type="checkbox" checked={ el.isDone }/> <span>{ el.title }</span></li>)}*/}
                    {/* it's better to use the last variant to add debugger, if it's necessary */}
                    {props.tasks.map(el => {
                        return (
                            <li>
                                <input type="checkbox" checked={el.isDone}/>
                                <span>{el.title}</span>
                                <button onClick={ () => {alert(el.title)} }>x</button>
                            </li>
                        );
                    })}
                </ul>
                <div>
                    <button>All</button>
                    <button>Active</button>
                    <button>Completed</button>
                </div>
            </div>
        </div>
    );
}